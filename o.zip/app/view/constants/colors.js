export const COLORS = {
  lightGreen: '#A3B18A',
  mediumGreen: '#588157',
  darkGreen: '#3A5A40',
  deepGreen: '#344E41',
  white: '#FFFFFF',
  black: '#000000',
};
