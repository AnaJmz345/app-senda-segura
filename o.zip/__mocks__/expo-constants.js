export default {
  expoConfig: {
    extra: {
      supabaseUrl: "http://localhost",
      supabaseAnonKey: "anon-key"
    }
  }
};
